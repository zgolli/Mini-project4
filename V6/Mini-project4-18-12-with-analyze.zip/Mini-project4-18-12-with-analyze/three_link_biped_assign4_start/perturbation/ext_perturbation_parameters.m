function [step_number, value] = ext_perturbation_parameters()

step_number = 10;
value = 80;

end