% If you are using the virtual constraints or trajectory based control
% methods, then you may cosider using a function such as this. 
function [hd, dhd] = desired_outputs(s, ds, q0, dq0, step_number)
%takes in current position and velocity, start position and velocity of
%step, and step number

%outputs desired position and velocity to track for q2



end