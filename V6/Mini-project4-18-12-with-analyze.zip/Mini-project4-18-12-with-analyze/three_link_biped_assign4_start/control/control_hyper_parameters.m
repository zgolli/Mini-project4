% You can set any hyper parameters of the control function here; you may or
% may not want to use the step_number as the input of the function. 
function [?] = control_hyper_parameters(step_number)


end
